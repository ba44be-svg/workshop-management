"""
Dispatch App Configuration
"""
from django.apps import AppConfig


class DispatchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.dispatch'
    verbose_name = 'پخش و بارگیری'
