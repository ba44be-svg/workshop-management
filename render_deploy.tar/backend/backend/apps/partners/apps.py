"""
Partners App Configuration
"""
from django.apps import AppConfig


class PartnersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.partners'
    verbose_name = 'فروشگاه‌ها و عوامل'
