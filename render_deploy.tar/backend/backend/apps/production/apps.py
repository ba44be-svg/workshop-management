"""
Production App Configuration
"""
from django.apps import AppConfig


class ProductionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.production'
    verbose_name = 'تولید'

    def ready(self):
        from . import signals  # noqa
