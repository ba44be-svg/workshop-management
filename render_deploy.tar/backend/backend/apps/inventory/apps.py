"""
Inventory App Configuration
"""
from django.apps import AppConfig


class InventoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.inventory'
    verbose_name = 'انبار و موجودی'

    def ready(self):
        from . import signals  # noqa
