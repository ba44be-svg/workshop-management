"""
Core package
"""
